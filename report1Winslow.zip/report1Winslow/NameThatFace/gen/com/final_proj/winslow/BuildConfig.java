/** Automatically generated file. DO NOT MODIFY */
package com.final_proj.winslow;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}